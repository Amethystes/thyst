document.addEventListener('DOMContentLoaded', function () {
  NProgress.start();
  console.log('1 2 step in the box get jiggy');
  console.log('1 2 step in the box get jiggy');
  console.log('1 2 step in the box get jiggy');
  console.log('1 2 step in the box get jiggy');
});

window.addEventListener('load', function () {
  NProgress.done();
});

